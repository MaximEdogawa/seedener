# seedener
Raspberry pi Zero HSM (Hardware Security Module) for Chia blockchain custody solution. To generate keys and air-gapped sign spend bundles.


#Donations to
- MaximEdogawa.xch
- did:chia:1w0hjc9aja50f0895f8lj3pfvxdcp3ngl0e0yk64lz3yw34js5mvstx2cnk
